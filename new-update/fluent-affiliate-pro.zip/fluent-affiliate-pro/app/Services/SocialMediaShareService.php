<?php

namespace FluentAffiliatePro\App\Services;

class SocialMediaShareService
{
    public static function getDefaultLinks()
    {
        static $links = null;
        if ($links !== null) {
            return $links;
        }

        $links = apply_filters('fluent_affiliate/social_media_links', [
            'twitter'   => [
                'title'       => __('X (Twitter)', 'fluent-affiliate-pro'),
                'icon_svg'    => '<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M11.202 8.863 16.88 2.5h-1.346L10.6 8.012 6.834 2.5H2.5l5.955 8.67L2.5 17.9h1.346l5.207-6.05L13.166 17.9H17.5l-6.298-9.037Zm-1.843 2.142-.603-.863L4.4 3.512h2.067l3.876 5.543.603.863 5.035 7.2h-2.067l-4.109-5.876-.446.763Z" fill="currentColor"/></svg>',
                'placeholder' => 'https://x.com/intent/tweet?url={url}&text={title}',
            ],
            'facebook'  => [
                'title'       => __('Facebook', 'fluent-affiliate-pro'),
                'icon_svg'    => '<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M10 1.667A8.333 8.333 0 1 0 18.333 10 8.342 8.342 0 0 0 10 1.667Zm2.083 5h-1.25c-.46 0-.833.186-.833.646V8.75h2.083l-.25 2.083H10V16.667H7.917V10.833H6.25V8.75h1.667V7.083a2.09 2.09 0 0 1 2.083-2.083h2.083v1.667Z" fill="currentColor"/></svg>',
                'placeholder' => 'https://facebook.com/sharer/sharer.php?u={url}',
            ],
            'linkedin'  => [
                'title'       => __('LinkedIn', 'fluent-affiliate-pro'),
                'icon_svg'    => '<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M15.833 2.5A1.667 1.667 0 0 1 17.5 4.167v11.666a1.667 1.667 0 0 1-1.667 1.667H4.167A1.667 1.667 0 0 1 2.5 15.833V4.167A1.667 1.667 0 0 1 4.167 2.5h11.666ZM5.833 7.5a1.042 1.042 0 1 0 0-2.083 1.042 1.042 0 0 0 0 2.083Zm-.833 1.25v5.833h1.667V8.75H5Zm3.333 0v5.833H10v-3.43c0-.966.458-1.57 1.257-1.57.74 0 1.076.583 1.076 1.57v3.43h1.667v-3.75c0-1.84-.833-2.917-2.5-2.917-.976 0-1.615.458-1.917.917V8.75H8.333Z" fill="currentColor"/></svg>',
                'placeholder' => 'https://linkedin.com/sharing/share-offsite/?url={url}',
            ],
            'whatsapp'  => [
                'title'       => __('WhatsApp', 'fluent-affiliate-pro'),
                'icon_svg'    => '<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M10.013 1.667A8.32 8.32 0 0 0 1.7 9.987a8.264 8.264 0 0 0 1.28 4.423L1.667 18.333l4.057-1.28A8.318 8.318 0 0 0 18.347 9.987a8.32 8.32 0 0 0-8.334-8.32Zm4.115 11.67c-.173.487-.997.933-1.393.993-.397.06-.763.277-2.543-.53-2.147-.973-3.51-3.16-3.617-3.307-.107-.147-.87-1.153-.87-2.2s.55-1.56.747-1.773c.197-.213.43-.267.573-.267.143 0 .287.003.413.007.133.007.31-.05.487.37.18.427.607 1.48.66 1.587.053.107.087.233.017.373-.07.14-.107.227-.213.35-.107.123-.223.273-.32.367-.107.107-.217.22-.093.433.123.213.55.907 1.18 1.467.81.72 1.493.943 1.707 1.05.213.107.337.09.46-.053.123-.143.53-.617.673-.83.143-.213.287-.177.487-.107.2.07 1.26.593 1.473.7.213.107.357.16.41.247.053.087.053.5-.12.987Z" fill="currentColor"/></svg>',
                'placeholder' => 'https://wa.me/?text={title}%20{url}',
            ],
            'email'     => [
                'title'       => __('Email', 'fluent-affiliate-pro'),
                'icon_svg'    => '<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3.25 4.25h13.5a.5.5 0 0 1 .5.5v11a.5.5 0 0 1-.5.5H3.25a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5Zm.25 11h13V5.81l-.834.746-5.615 5.028-5.72-5.047L3.5 5.804V15.25Zm.553-9.625 5.662 5L9.713 10.915l.331-.296 5.581-4.997.975-.872H3.06l.742.875Z" fill="currentColor"/></svg>',
                'placeholder' => 'mailto:?subject={title}&body={url}',
            ],
            'reddit'    => [
                'title'       => __('Reddit', 'fluent-affiliate-pro'),
                'icon_svg'    => '<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M10 1.667C5.398 1.667 1.667 5.398 1.667 10S5.398 18.333 10 18.333 18.333 14.602 18.333 10 14.602 1.667 10 1.667Zm5.417 9.583a1.46 1.46 0 0 1-.209.75c.042.208.042.417.042.625 0 2.292-2.708 4.167-6.042 4.167S3.167 14.917 3.167 12.625c0-.208 0-.417.042-.625A1.458 1.458 0 0 1 4.583 10a1.46 1.46 0 0 1 .959.375A7.725 7.725 0 0 1 9.583 9.25l.834-3.333.041-.084a.208.208 0 0 1 .167-.083L10.708 5.833l2.5.542a1.042 1.042 0 1 1-.125.625l-2.166-.459-.709 2.792a7.54 7.54 0 0 1 3.834 1.042c.291-.25.666-.375 1.041-.375a1.458 1.458 0 0 1 1.334 2Zm-8.75 1.25a.833.833 0 1 0 1.666 0 .833.833 0 0 0-1.666 0Zm5.416.834a.833.833 0 1 0 0-1.667.833.833 0 0 0 0 1.666Zm-4.541 1.875c.75.5 1.5.708 2.458.708s1.708-.208 2.458-.708.042-.584-.291-.375c-.584.375-1.25.583-2.167.583s-1.583-.208-2.167-.583c-.375-.209-.708.083-.291.375Z" fill="currentColor"/></svg>',
                'placeholder' => 'https://reddit.com/submit?url={url}&title={title}',
            ],
            'telegram'  => [
                'title'       => __('Telegram', 'fluent-affiliate-pro'),
                'icon_svg'    => '<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M10 1.667A8.333 8.333 0 1 0 18.333 10 8.342 8.342 0 0 0 10 1.667Zm3.98 5.713-1.38 6.507c-.103.46-.373.573-.757.357l-2.093-1.54-1.01.97c-.112.112-.205.205-.42.205l.15-2.13 3.877-3.503c.168-.15-.037-.233-.262-.083L7.11 10.82 5.043 10.172c-.45-.14-.458-.45.093-.667l8.08-3.113c.375-.135.703.09.58.665l.184.323Z" fill="currentColor"/></svg>',
                'placeholder' => 'https://t.me/share/url?url={url}&text={title}',
            ],
            'pinterest' => [
                'title'       => __('Pinterest', 'fluent-affiliate-pro'),
                'icon_svg'    => '<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M10 1.667A8.333 8.333 0 1 0 18.333 10 8.342 8.342 0 0 0 10 1.667Zm.517 10.583c-.733 0-1.425-.396-1.663-.847l-.48 1.896c-.34 1.275-1.34 2.55-1.416 2.654a.157.157 0 0 1-.29-.083c-.04-.396-.498-3.074.003-5.35l.93-3.937s-.232-.463-.232-1.146c0-1.072.622-1.873 1.397-1.873.658 0 .977.494.977 1.087 0 .662-.422 1.652-.64 2.568-.182.768.386 1.394 1.144 1.394 1.373 0 2.294-1.765 2.294-3.856 0-1.59-1.07-2.78-3.017-2.78-2.2 0-3.573 1.64-3.573 3.473 0 .632.186 1.078.476 1.423.133.158.152.22.103.401-.035.132-.113.45-.147.576-.048.183-.197.249-.363.181-1.013-.413-1.486-1.522-1.486-2.769 0-2.058 1.735-4.527 5.177-4.527 2.766 0 4.582 2.003 4.582 4.151 0 2.843-1.58 4.967-3.906 4.967l.13-.229Z" fill="currentColor"/></svg>',
                'placeholder' => 'https://pinterest.com/pin/create/button/?url={url}&description={title}',
            ],
        ]);

        return $links;
    }

    public static function getDefaultEnabledKeys()
    {
        $defaultEnabled = ['facebook', 'twitter', 'linkedin', 'whatsapp', 'email'];

        return apply_filters('fluent_affiliate/social_media_share_default_enabled_keys', $defaultEnabled);
    }

    public static function getRegisteredLinkKeys()
    {
        return array_keys(self::getDefaultLinks());
    }
}
