<?php

namespace FluentAffiliatePro\App\Services\Integrations\FluentCart;

use FluentAffiliate\App\Helper\Helper;
use FluentAffiliate\App\Helper\Utility;
use FluentAffiliate\App\Models\Affiliate;
use FluentAffiliate\App\Models\Referral;
use FluentAffiliate\Framework\Support\Arr;
use FluentAffiliate\App\Modules\Integrations\FluentCart\Bootstrap;
use FluentAffiliatePro\App\Services\Integrations\RecurringCommissionTrait;

class RecurringReferral extends Bootstrap
{
    use RecurringCommissionTrait;

    public function register()
    {
        if (!$this->isEnabled()) {
            return;
        }

        $isGlobalEnabled = Utility::getReferralSetting('enable_subscription_renewal', 'no') === 'yes';
        $isConnectorEnabled = $this->getSetting('enable_subscription_renewal') === 'yes';

        if (!$isGlobalEnabled || !$isConnectorEnabled) {
            return;
        }

        add_action('fluent_cart/subscription_renewed', [$this, 'handleSubscriptionRenewal'], 99, 1);
    }

    public function handleSubscriptionRenewal($event)
    {
        $renewalOrder = $event['order'];
        $parentOrder = $event['main_order'];

        if ($this->getExistingReferral($renewalOrder->id)) {
            return;
        }

        $parentReferral = Referral::where('provider', $this->provider)
            ->where('provider_id', $parentOrder->id)
            ->where('type', 'sale')
            ->first();

        if (!$parentReferral) {
            return;
        }

        $affiliate = Affiliate::find($parentReferral->affiliate_id);
        if (!$affiliate || $affiliate->status !== 'active') {
            return;
        }

        $maxCount = $this->getMaxRenewalCount($affiliate);
        if ($maxCount > 0) {
            $existingCount = Referral::where('parent_id', $parentReferral->id)
                ->where('type', 'recurring_sale')
                ->count();
            if ($existingCount + 1 >= $maxCount) {
                return;
            }
        }

        // Format the renewal order data
        $orderData = $this->getFormattedOrderData($renewalOrder);
        if (!$orderData) {
            return;
        }

        $orderTotal = $this->calculateOrderTotal($orderData);

        $commission = $this->calculateFinalRecurringCommissionAmount($affiliate, $orderData, 'product-categories');

        $commission = apply_filters('fluent_affiliate/recurring_commission', $commission, [
            'affiliate'       => $affiliate,
            'order_data'      => $orderData,
            'provider'        => $this->provider,
            'vendor_order'    => $renewalOrder,
            'parent_referral' => $parentReferral
        ]);

        $formattedItems = Arr::get($orderData, 'items');

        $description = $formattedItems[0]['title'] ?? 'Renewal Order';
        if (count($formattedItems) > 1) {
            $description .= ' and ' . (count($formattedItems) - 1) . ' more items';
        }

        $description .= ' (Renewal)';

        $status = 'pending';
        if ($renewalOrder->payment_status == 'paid') {
            $status = 'unpaid';
        }

        $referralData = [
            'affiliate_id' => $affiliate->id,
            'customer_id'  => $parentReferral->customer_id,
            'visit_id'     => $parentReferral->visit_id,
            'parent_id'    => $parentReferral->id,
            'description'  => $description,
            'status'       => $status,
            'type'         => 'recurring_sale',
            'amount'       => $commission,
            'order_total'  => $orderTotal,
            'currency'     => $renewalOrder->currency,
            'utm_campaign' => $parentReferral->utm_campaign,
            'provider'     => $this->provider,
            'provider_id'  => $renewalOrder->id,
            'products'     => $formattedItems
        ];

        $referral = $this->recordReferral($referralData);
        if (!$referral) {
            return;
        }

        do_action('fluent_affiliate/recurring_referral_created', $referral);

        $affiliateName = $affiliate->user ? $affiliate->user->display_name : 'unknown';
        $amountLink = '<a target="_blank" rel="noopener" href="' . Utility::getAdminPageUrl('referrals/' . $referral->id . '/view') . '">' . Helper::formatMoney($referral->amount, $referral->currency) . '</a>';

        // translators: %1$s is the affiliate name, %2$s is the referral amount with link
        $description = sprintf(__('Recurring referral has been created for affiliate: %1$s. Amount: %2$s', 'fluent-affiliate-pro'), $affiliateName, $amountLink);

        $renewalOrder->addLog(__('Fluent Affiliate recurring referral created.', 'fluent-affiliate-pro'), $description);
    }

}
