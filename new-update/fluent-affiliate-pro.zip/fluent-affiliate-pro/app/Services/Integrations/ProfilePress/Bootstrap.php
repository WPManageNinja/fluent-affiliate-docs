<?php

namespace FluentAffiliatePro\App\Services\Integrations\ProfilePress;

use FluentAffiliate\App\Models\Referral;
use FluentAffiliate\App\Modules\Integrations\BaseConnector;
use FluentAffiliate\Framework\Support\Arr;
use ProfilePress\Core\Membership\Models\Order\OrderEntity;
use ProfilePress\Core\Membership\Models\Order\OrderFactory;

class Bootstrap extends BaseConnector
{

    protected $provider = 'profilepress';

    public function register()
    {
        if (!$this->isEnabled()) {
            return;
        }

        add_action('ppress_order_added', [$this, 'createPendingReferral']);
        add_action('ppress_order_updated', [$this, 'markReferralComplete'], 10, 2);

        add_action('ppress_order_refunded', [$this, 'markReferralRevoked']);
        add_action('ppress_order_deleted', [$this, 'markReferralRevoked'], 10);

        add_filter('fluent_affiliate/provider_reference_profilepress_url', [$this, 'getOrderLink'], 10, 2);
    }

    public function createPendingReferral($order_id)
    {
        if (Referral::where('provider', $this->provider)->where('provider_id', $order_id)->exists()) {
            return;
        }

        $affiliate = $this->getCurrentAffiliate();
        if (!$affiliate) {
            return;
        }

        $visit = $this->getCurrentVisit($affiliate);

        $order = OrderFactory::fromId($order_id);

        if (!$order->exists()) return;

        $orderData = $this->getFormattedOrderData($order);

        $customerData = $orderData['customer'];

        if ($this->isSelfReferred($affiliate, $customerData)) {
            return; // Do not create referral for self-referrals
        }

        $customerData['by_affiliate_id'] = $affiliate->id;
        $affiliatedCustomer = $this->addOrUpdateCustomer($customerData);

        $commissionAmount = $this->calculateFinalCommissionAmount($affiliate, $orderData, '');


        $referralData = [
            'affiliate_id' => $affiliate->id,
            'customer_id'  => $affiliatedCustomer->id,
            'visit_id'     => $visit->id ? $visit->id : null,
            'description'  => $orderData['description'],
            'status'       => $orderData['status'],
            'type'         => 'sale',
            'amount'       => $commissionAmount,
            'order_total'  => $orderData['referral_order_total'],
            'currency'     => $orderData['currency'],
            'utm_campaign' => $visit ? $visit->utm_campaign : null,
            'provider'     => $this->provider,
            'provider_id'  => $orderData['id'],
            'products'     => $orderData['items'],
        ];

        $this->recordReferral($referralData);
    }

    public function markReferralComplete($result, $order)
    {
        if (!$result || !$order->exists() || !$order->is_completed()) return;

        $referral = $this->getExistingReferral($order->get_id());

        if (!$referral) {
            return; // No referral found for this order
        }

        $this->markReferralAsUnpaid($referral);

        $order->add_note(
            sprintf(
            /* translators: 1: Amount, 2: Affiliate Name, 3: Affiliate ID */
                __('Referral amount %1$s recorded for %2$s (ID: %3$d).', 'fluent-affiliate-pro'),
                $referral->amount,
                Arr::get($referral->affiliate->user_details, 'full_name', ''),
                $referral->affiliate_id
            )
        );

    }

    public function markReferralRevoked($order)
    {
        $referral = $this->getExistingReferral($order->get_id());
        if ($referral) {
            $this->rejectReferral($referral);
        }
    }

    public function getOrderLink($link, $referral)
    {
        return admin_url("admin.php?page=ppress-orders&ppress_order_action=edit&id={$referral->provider_id}");
    }

    private function getFormattedOrderData(OrderEntity $order)
    {
        // get customer email.
        $customer_email = $order->get_customer_email();

        $plan = $order->get_plan();

        // Referral description.
        $description = $plan->get_name();

        return [
            'id'                   => $order->id,
            'total'                => $order->get_total(),
            'subtotal'             => $order->get_subtotal(),
            'referral_order_total' => $order->get_total(),
            'tax'                  => $order->get_tax(),
            'discount'             => 0,
            'status'               => $order->is_completed() ? 'paid' : 'pending',
            'currency'             => $order->currency,
            'description'          => $description,
            'customer'             => $this->getCustomer($order),
            'items'                => [
                [
                    'item_id'  => $plan->get_id(),
                    'title'    => $description,
                    'subtotal' => $order->get_subtotal(),
                    'tax'      => $order->get_tax(),
                    'shipping' => 0,
                    'total'    => $order->get_total(),
                ]
            ]
        ];
    }


    public function getCustomer($order)
    {
        $_customer = $order->get_customer();
        return [
            'user_id'    => $_customer->get_user_id(),
            'email'      => $_customer->get_email(),
            'first_name' => $_customer->get_first_name(),
            'last_name'  => $_customer->get_last_name(),
            'ip'         => $order->ip_address
        ];
    }
}
