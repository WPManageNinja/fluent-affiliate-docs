<?php

namespace FluentAffiliatePro\App\Services\Integrations\ProfilePress;

use FluentAffiliate\App\Helper\Utility;
use FluentAffiliate\App\Modules\Integrations\BaseConnectorSettings;

class Connector extends BaseConnectorSettings
{
    protected $integration = 'profilepress';

    public function init()
    {
        $this->register();
    }

    public function isAvailable()
    {
        return defined('\PPRESS_VERSION_NUMBER');
    }

    public function getInfo()
    {
        return [
            'integration'    => $this->integration,
            'title'          => 'ProfilePress',
            'description'    => 'Connect FluentAffiliate with ProfilePress Memberships to track sales and commissions',
            'type'           => 'lms',
            'logo'           => Utility::asset('images/integrations/profilepress.png'),
            'is_unavailable' => !$this->isAvailable(),
            'config'         => $this->config(),
        ];
    }

    public function config()
    {
        $defaults = [
            'is_enabled'             => 'no',
            'custom_affiliate_rate'  => 'no',
            'custom_affiliate_rates' => [],
        ];

        if (!$this->willConnectorRun()) {
            return $defaults;
        }

        $settings = Utility::getOption('_' . $this->integration . '_connector_config', []);

        return wp_parse_args($settings, $defaults);
    }

    public function getProductCatOptions($options = [], $params = [])
    {
        $plans = FluentAffiliate('db')->table('ppress_plans')->orderBy('name', 'asc')->get();

        $formattedPlans = [];
        foreach ($plans as $plan) {
            $formattedPlans[] = [
                'id'    => $plan->id,
                'label' => $plan->name,
            ];
        }

        return $formattedPlans;
    }

    public function getConfigFields()
    {
        return [
            'custom_rate_component' => [
                'type'           => 'custom_rate_component',
                'has_categories' => false,
                'product_label'  => __('Select Plans', 'fluent-affiliate-pro'),
                'has_products'   => true,
                'main_label'     => __('Enable custom rate for specific plans', 'fluent-affiliate-pro'),
            ]
        ];
    }

}
