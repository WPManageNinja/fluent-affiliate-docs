<?php

namespace FluentAffiliatePro\App\Services\Integrations;

use FluentAffiliate\App\Helper\Utility;
use FluentAffiliate\Framework\Support\Arr;

defined('ABSPATH') || exit;

/**
 * Resolves the lifetime commission rate for an affiliate, honouring a per-group
 * override before falling back to the global lifetime settings.
 */
trait LifetimeCommissionTrait
{
    private function getAffiliateLifetimeGroupValue($affiliate)
    {
        if ($affiliate->rate_type == 'group' && $affiliate->group()->exists()) {
            $groupValue = $affiliate->group->value;
            if (Arr::get($groupValue, 'enable_lifetime_commission', 'no') === 'yes') {
                return $groupValue;
            }
        }

        return null;
    }

    public function getLifetimeExpiryDays($affiliate)
    {
        $global     = (int) Utility::getReferralSetting('lifetime_expiry_days', 0);
        $groupValue = $this->getAffiliateLifetimeGroupValue($affiliate);

        if ($groupValue) {
            // An unset group expiry inherits the global value instead of meaning "never".
            $groupDays = (int) Arr::get($groupValue, 'lifetime_expiry_days', 0);
            return $groupDays > 0 ? $groupDays : $global;
        }

        return $global;
    }

    public function getBaseLifetimeCommission($affiliate, $amount)
    {
        $groupValue = $this->getAffiliateLifetimeGroupValue($affiliate);

        if ($groupValue) {
            $rate     = (float) Arr::get($groupValue, 'lifetime_rate', 0);
            $rateType = Arr::get($groupValue, 'lifetime_rate_type', 'percentage');
            return $rateType === 'percentage' ? ($amount * $rate) / 100 : $rate;
        }

        $rate     = (float) Utility::getReferralSetting('lifetime_rate', 0);
        $rateType = Utility::getReferralSetting('lifetime_rate_type', 'percentage');
        return $rateType === 'percentage' ? ($amount * $rate) / 100 : $rate;
    }
}
