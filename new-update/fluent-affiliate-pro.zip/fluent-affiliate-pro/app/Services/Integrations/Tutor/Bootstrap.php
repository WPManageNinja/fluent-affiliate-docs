<?php

namespace FluentAffiliatePro\App\Services\Integrations\Tutor;

use FluentAffiliate\App\Models\Referral;
use FluentAffiliate\App\Modules\Integrations\BaseConnector;
use FluentAffiliate\App\Services\VisitService;
use FluentAffiliate\Framework\Support\Arr;
use Tutor\Models\OrderMetaModel;

class Bootstrap extends BaseConnector
{

    protected $provider = 'tutorlms';

    public function register()
    {
        if (!$this->isEnabled()) {
            return;
        }

        add_action('tutor_order_placed', [$this, 'createPendingReferral']);
        add_action('tutor_after_order_mark_as_paid', [$this, 'markReferralComplete']);

        // revoke referral when order is refunded
        add_action('tutor_order_payment_status_changed', [$this, 'markReferralRevoked'], 10, 3);

        add_filter('fluent_affiliate/provider_reference_tutorlms_url', [$this, 'getOrderLink'], 10, 2);
    }

    public function createPendingReferral($srcOrderData)
    {
        $orderId = Arr::get($srcOrderData, 'id');

        if (!$orderId) {
            return;
        }

        if (Referral::where('provider', $this->provider)->where('provider_id', $orderId)->exists()) {
            return;
        }

        $affiliate = $this->getCurrentAffiliate();
        if (!$affiliate) {
            return;
        }

        $visit = $this->getCurrentVisit($affiliate);

        $orderData = $this->getFormattedOrderData($srcOrderData);

        $customerData = $orderData['customer'];

        if ($this->isSelfReferred($affiliate, $customerData)) {
            return; // Do not create referral for self-referrals
        }

        $customerData['by_affiliate_id'] = $affiliate->id;
        $affiliatedCustomer = $this->addOrUpdateCustomer($customerData);

        $commissionAmount = $this->calculateFinalCommissionAmount($affiliate, $orderData, 'course_cat');

        $referralData = [
            'affiliate_id' => $affiliate->id,
            'customer_id'  => $affiliatedCustomer->id,
            'visit_id'     => $visit ? $visit->id : null,
            'description'  => $orderData['description'],
            'status'       => $orderData['status'],
            'type'         => 'sale',
            'amount'       => $commissionAmount,
            'order_total'  => $orderData['referral_order_total'],
            'currency'     => $orderData['currency'],
            'utm_campaign' => $visit ? $visit->utm_campaign : null,
            'provider'     => $this->provider,
            'provider_id'  => $orderData['id'],
            'products'     => $orderData['items'],
        ];

        $this->recordReferral($referralData);
    }

    public function markReferralComplete($order)
    {
        $referral = $this->getExistingReferral($order->id);
        if (!$referral) {
            return; // No referral found for this order
        }

        $this->markReferralAsUnpaid($referral);
    }

    public function markReferralRevoked($orderId, $oldStatus, $newStatus)
    {
        $watchingStatuses = ['refunded', 'failed', 'unpaid'];
        if (!in_array($newStatus, $watchingStatuses)) {
            return;
        }

        $referral = $this->getExistingReferral($orderId);
        if ($referral) {
            $this->rejectReferral($referral);
        }
    }

    public function getOrderLink($link, $referral)
    {
        return admin_url("admin.php?page=tutor_orders&action=edit&id={$referral->provider_id}");
    }

    private function getFormattedOrderData($srcOrderData)
    {
        $orderId = Arr::get($srcOrderData, 'id');
        $products = [];

        foreach ($srcOrderData['items'] as $item) {
            $itemId = Arr::get($item, 'item_id');
            $product = get_post($itemId);
            $price = Arr::get($item, 'sale_price', 0);
            if (!$price) {
                $price = Arr::get($item, 'regular_price', 0);
            }

            $products[] = [
                'item_id'  => $itemId,
                'title'    => $product ? $product->post_title : 'Course - ' . $itemId,
                'subtotal' => $price,
                'tax'      => 0,
                'shipping' => 0,
                'total'    => $price,
            ];
        }

        $user = get_user_by('ID', Arr::get($srcOrderData, 'user_id'));

        $description = 'Purchase of ';
        $productTitles = array_map(function ($prod) {
            return $prod['title'];
        }, $products);

        $description .= implode(', ', $productTitles);
        $paymentTotal = Arr::get($srcOrderData, 'net_payment', 0);

        $customerData = [];

        if ($user) {
            $customerData = array_filter([
                'email'      => $user ? $user->user_email : '',
                'first_name' => $user ? $user->first_name : '',
                'last_name'  => $user ? $user->last_name : '',
                'ip'         => VisitService::getIp(),
                'user_id'    => $user ? $user->ID : '',
            ]);
        } else {
            $billing_address = OrderMetaModel::get_meta_value($orderId, 'billing_address', true);
            if ($billing_address) {
                $billing_address = json_decode($billing_address, true);
                $customerData = array_filter([
                    'email'      => Arr::get($billing_address, 'billing_email', ''),
                    'first_name' => Arr::get($billing_address, 'billing_first_name', ''),
                    'last_name'  => Arr::get($billing_address, 'billing_last_name', ''),
                    'ip'         => VisitService::getIp(),
                    'user_id'    => Arr::get($billing_address, 'user_id', ''),
                ]);
            }
        }

        return [
            'id'                   => $orderId,
            'total'                => $paymentTotal,
            'subtotal'             => $paymentTotal,
            'referral_order_total' => $paymentTotal,
            'tax'                  => 0,
            'discount'             => 0,
            'status'               => (Arr::get($srcOrderData, 'payment_status') === 'paid') ? 'paid' : 'pending',
            'currency'             => tutor_utils()->get_option('currency_code', 'USD'),
            'description'          => $description,
            'customer'             => $customerData,
            'items'                => $products
        ];
    }
}
