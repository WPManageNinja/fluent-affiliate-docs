<?php

namespace FluentAffiliatePro\App\Services\Integrations;

use FluentAffiliate\App\Helper\Utility;
use FluentAffiliate\Framework\Support\Arr;

defined('ABSPATH') || exit;

/**
 * Intended for use in pro RecurringReferral classes that already extend a BaseConnector subclass.
*/
trait RecurringCommissionTrait
{
    private function getAffiliateRenewalGroupValue($affiliate)
    {
        if ($affiliate->rate_type == 'group' && $affiliate->group()->exists()) {
            $groupValue = $affiliate->group->value;
            if (Arr::get($groupValue, 'enable_subscription_renewal', 'no') === 'yes') {
                return $groupValue;
            }
        }

        return null;
    }

    protected function getMaxRenewalCount($affiliate)
    {
        $groupValue = $this->getAffiliateRenewalGroupValue($affiliate);

        if ($groupValue) {
            return (int) Arr::get($groupValue, 'max_renewal_count', 0);
        }

        return (int) Utility::getReferralSetting('max_renewal_count', 0);
    }

    public function getBaseRenewalCommission($affiliate, $amount)
    {
        $groupValue = $this->getAffiliateRenewalGroupValue($affiliate);

        if ($groupValue) {
            $rate     = (float) Arr::get($groupValue, 'renewal_rate', 0);
            $rateType = Arr::get($groupValue, 'renewal_rate_type', 'percentage');
            return $rateType === 'percentage' ? ($amount * $rate) / 100 : $rate;
        }

        $rate     = (float) Utility::getReferralSetting('renewal_rate', 0);
        $rateType = Utility::getReferralSetting('renewal_rate_type', 'percentage');
        return $rateType === 'percentage' ? ($amount * $rate) / 100 : $rate;
    }

    public function calculateFinalRecurringCommissionAmount($affiliate, $orderData, $taxonomy = '')
    {
        $config             = $this->getConfig();
        $referralOrderTotal = Arr::get($orderData, 'referral_order_total');

        $hasCustomRates = Arr::get($config, 'renewal_custom_affiliate_rate') === 'yes'
            && (Arr::get($config, 'renewal_watched_product_ids') || Arr::get($config, 'renewal_watched_cat_ids'));

        if (!$hasCustomRates) {
            return $this->getBaseRenewalCommission($affiliate, $referralOrderTotal);
        }

        $orderedProductIds = array_filter(array_column($orderData['items'], 'item_id'));

        if (!$orderedProductIds) {
            return $this->getBaseRenewalCommission($affiliate, $referralOrderTotal);
        }

        $watchedCatIds = Arr::get($config, 'renewal_watched_cat_ids', []);
        $termMaps      = ($watchedCatIds && $taxonomy)
            ? $this->getPostTermsMaps($orderedProductIds, $taxonomy)
            : [];

        $keyedRates  = [];
        $customRates = Arr::get($config, 'renewal_custom_affiliate_rates', []);

        foreach ($customRates as $rate) {
            if ($rate['object_type'] === 'product') {
                foreach (array_intersect(Arr::get($rate, 'object_ids', []), $orderedProductIds) as $productId) {
                    if (!isset($keyedRates[$productId])) {
                        $keyedRates[$productId] = ['rate' => $rate['rate'], 'type' => $rate['rate_type']];
                    }
                }
            } elseif ($rate['object_type'] === 'category') {
                foreach ($termMaps as $productId => $termIds) {
                    if (!isset($keyedRates[$productId]) && array_intersect($termIds, Arr::get($rate, 'object_ids', []))) {
                        $keyedRates[$productId] = ['rate' => $rate['rate'], 'type' => $rate['rate_type']];
                    }
                }
            }
        }

        $byRulesTotal = 0;

        foreach ($orderData['items'] as $item) {
            $itemId = (string) Arr::get($item, 'item_id');
            if (!isset($keyedRates[$itemId])) {
                continue;
            }
            $itemTotal          = $this->calculateOrderTotal($item);
            $byRulesTotal       += $this->calculateCustomCommission($itemTotal, $keyedRates[$itemId]);
            $referralOrderTotal -= $itemTotal;
        }

        if ($referralOrderTotal <= 0) {
            return $byRulesTotal;
        }

        return $byRulesTotal + $this->getBaseRenewalCommission($affiliate, $referralOrderTotal);
    }
}
