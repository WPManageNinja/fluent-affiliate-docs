<?php

namespace FluentAffiliatePro\App\Http\Controllers;

use FluentAffiliate\App\Http\Controllers\Controller;
use FluentAffiliate\App\Models\Affiliate;
use FluentAffiliate\App\Models\Customer;
use FluentAffiliate\App\Services\PermissionManager;
use FluentAffiliate\Framework\Http\Request\Request;

defined('ABSPATH') || exit;

class LifetimeCommissionController extends Controller
{
    public function searchCustomers(Request $request, $affiliateId)
    {
        $affiliate = Affiliate::query()->with('user')->findOrFail($affiliateId);

        $customers = Customer::query()
            ->with(['affiliate.user'])
            ->searchBy($request->getSafe('search', 'sanitize_text_field'))
            // Exclude customers already linked to this affiliate (they're in the list already).
            ->where(function ($query) use ($affiliate) {
                $query->whereNull('by_affiliate_id')
                    ->orWhere('by_affiliate_id', '!=', $affiliate->id);
            })
            ->orderBy('id', 'desc')
            ->limit(20)
            ->get();

        // Only admins can transfer a customer away from another affiliate.
        $isAdmin = PermissionManager::isAdmin();

        $options = [];
        foreach ($customers as $customer) {
            $name   = trim($customer->full_name);
            $label  = $name ? "{$name} ({$customer->email})" : $customer->email;
            $linked = !empty($customer->by_affiliate_id);

            if ($linked) {
                $label .= ' — ' . __('already linked', 'fluent-affiliate-pro');
            }

            $options[] = [
                'value'                 => $customer->id,
                'label'                 => $label,
                'email'                 => $customer->email,
                'disabled'              => $linked && !$isAdmin,
                'linked_affiliate_id'   => $linked ? (int) $customer->by_affiliate_id : null,
                'linked_affiliate_name' => $linked ? $this->affiliateName($customer->affiliate) : ''
            ];
        }

        return [
            'customers' => $options,
            'affiliate' => $affiliate
        ];
    }

    public function link(Request $request, $affiliateId)
    {
        $affiliate = Affiliate::query()->findOrFail($affiliateId);

        if ($affiliate->status !== 'active') {
            return $this->sendError([
                'message' => __('You cannot link customers to an inactive affiliate.', 'fluent-affiliate-pro')
            ]);
        }

        $customerId = (int) $request->getSafe('customer_id', 'intval');
        $email      = $request->getSafe('email', 'sanitize_email');

        $customer = $customerId
            ? Customer::query()->find($customerId)
            : Customer::query()->where('email', $email)->first();

        if (!$customer) {
            return $this->sendError([
                'message' => __('No customer was found for the provided details.', 'fluent-affiliate-pro')
            ]);
        }

        if ((int) $customer->by_affiliate_id === (int) $affiliate->id) {
            return [
                'message'  => __('Customer is already linked to this affiliate.', 'fluent-affiliate-pro'),
                'customer' => $customer
            ];
        }

        // Linked to another affiliate: only an explicit, admin-confirmed transfer may reassign.
        if (!empty($customer->by_affiliate_id)) {
            $isTransfer = $request->getSafe('transfer', 'rest_sanitize_boolean');

            if (!$isTransfer || !PermissionManager::isAdmin()) {
                return $this->sendError([
                    'message' => __('This customer is already linked to another affiliate.', 'fluent-affiliate-pro')
                ]);
            }

            $fromAffiliate             = Affiliate::find($customer->by_affiliate_id);
            $customer->by_affiliate_id = $affiliate->id;
            $customer->save();

            return [
                'message'  => sprintf(
                    // translators: %1$s previous affiliate name, %2$s new affiliate name
                    __('Customer transferred from %1$s to %2$s. Future purchases will be credited to %2$s.', 'fluent-affiliate-pro'),
                    $this->affiliateName($fromAffiliate),
                    $this->affiliateName($affiliate)
                ),
                'customer' => $customer
            ];
        }

        $customer->by_affiliate_id = $affiliate->id;
        $customer->save();

        return [
            'message'  => __('Customer linked to the affiliate successfully', 'fluent-affiliate-pro'),
            'customer' => $customer
        ];
    }

    protected function affiliateName($affiliate)
    {
        if (!$affiliate) {
            return '';
        }

        return $affiliate->user ? $affiliate->user->full_name : '#' . $affiliate->id;
    }

    public function unlink(Request $request, $affiliateId, $customerId)
    {
        $customer = Customer::query()
            ->where('by_affiliate_id', $affiliateId)
            ->findOrFail($customerId);

        $customer->by_affiliate_id = null;
        $customer->save();

        return [
            'message' => __('Customer unlinked from the affiliate successfully', 'fluent-affiliate-pro')
        ];
    }
}
