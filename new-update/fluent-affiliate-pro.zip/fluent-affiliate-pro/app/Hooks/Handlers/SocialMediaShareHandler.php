<?php

namespace FluentAffiliatePro\App\Hooks\Handlers;

use FluentAffiliate\App\Helper\Utility;
use FluentAffiliate\Framework\Support\Arr;
use FluentAffiliatePro\App\Services\SocialMediaShareService;

class SocialMediaShareHandler
{
    public function register()
    {
        add_filter('fluent_affiliate/update_feature_settings_social_media_share', [$this, 'handleSettings'], 10, 1);
        add_filter('fluent_affiliate/update_feature_response_social_media_share', [$this, 'getSettings'], 10, 2);
        add_filter('fluent_affiliate/get_feature_settings_social_media_share', [$this, 'getSettings'], 10, 2);
        add_filter('fluent_affiliate/portal_localize_data', [$this, 'addPortalSocialLinks'], 10, 1);
    }

    public function handleSettings($settings)
    {
        $platforms = (array) $settings;

        if (empty($platforms)) {
            return $settings;
        }

        if (count($platforms) > 20) {
            return new \WP_Error('too_many_platforms', __('Too many platforms provided.', 'fluent-affiliate-pro'));
        }

        $validKeys = SocialMediaShareService::getRegisteredLinkKeys();

        $sanitized = [];
        foreach ($platforms as $platform) {
            $key = sanitize_text_field(Arr::get($platform, 'key', ''));
            if (!$key || !in_array($key, $validKeys)) {
                continue;
            }
            $sanitized[] = [
                'key'     => $key,
                'enabled' => Arr::get($platform, 'enabled') === 'yes' ? 'yes' : 'no',
            ];
        }

        return $sanitized;
    }

    public function getSettings($response, $saved)
    {
        $savedSettings = Arr::get($saved, 'social_media_share.settings', []);
        $response['platforms'] = self::buildPlatforms(
            SocialMediaShareService::getDefaultLinks(),
            $savedSettings
        );

        return $response;
    }

    public function addPortalSocialLinks($data)
    {
        if (!Utility::isFeatureEnabled('social_media_share')) {
            return $data;
        }

        $saved         = Utility::getOption('fluent_affiliate_features', []);
        $savedSettings = Arr::get($saved, 'social_media_share.settings', []);
        $platforms     = self::buildPlatforms(SocialMediaShareService::getDefaultLinks(), $savedSettings);

        $data['social_links'] = array_values(array_filter($platforms, fn($p) => $p['enabled'] === 'yes'));

        return $data;
    }

    /**
     * Merge default links with saved settings (order + enabled state).
     * Returns indexed array with 'key' injected into each entry.
     */
    private static function buildPlatforms($defaults, $savedSettings)
    {
        if (empty($savedSettings)) {
            $platforms = [];
            $defaultEnabledKeys = SocialMediaShareService::getDefaultEnabledKeys();
            foreach ($defaults as $key => $link) {
                $link['key'] = $key;
                $link['enabled'] = in_array($key, $defaultEnabledKeys) ? 'yes' : 'no';
                $platforms[] = $link;
            }
            return $platforms;
        }

        $platforms = [];
        $usedKeys = [];

        foreach ($savedSettings as $item) {
            $key = Arr::get($item, 'key', '');
            if (!$key || !isset($defaults[$key])) {
                continue;
            }
            $link            = $defaults[$key];
            $link['key']     = $key;
            $link['enabled'] = Arr::get($item, 'enabled') === 'yes' ? 'yes' : 'no';
            $platforms[] = $link;
            $usedKeys[] = $key;
        }

        // Append any new defaults not in saved
        $usedKeysFlipped = array_flip($usedKeys);
        foreach ($defaults as $key => $link) {
            if (!isset($usedKeysFlipped[$key])) {
                $link['key'] = $key;
                $link['enabled'] = 'no';
                $platforms[] = $link;
            }
        }

        return $platforms;
    }
}
