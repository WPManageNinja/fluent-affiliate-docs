<?php

namespace FluentAffiliatePro\App\Hooks\Handlers;

use FluentAffiliate\App\Helper\Utility;
use FluentAffiliate\App\Models\Affiliate;
use FluentAffiliate\App\Models\Customer;
use FluentAffiliate\Framework\Support\Arr;
use FluentAffiliatePro\App\Services\Integrations\LifetimeCommissionTrait;

defined('ABSPATH') || exit;

class LifetimeCommissionHandler
{
    use LifetimeCommissionTrait;

    public function register()
    {
        add_filter('fluent_affiliate/default_referral_settings', [$this, 'addDefaultLifetimeSettings']);
        add_filter('fluent_affiliate/referral_config_field_types', [$this, 'addLifetimeFieldTypes']);

        if (Utility::getReferralSetting('enable_lifetime_commission', 'no') !== 'yes') {
            return;
        }

        add_filter('fluent_affiliate/create_affiliate_group_data_value', [$this, 'addLifetimeSettingsToGroup'], 10, 2);
        add_filter('fluent_affiliate/update_affiliate_group_data_value', [$this, 'addLifetimeSettingsToGroup'], 10, 2);

        add_filter('fluent_affiliate/checkout_affiliate', [$this, 'resolveAffiliate'], 10, 3);
        add_filter('fluent_affiliate/referral_data', [$this, 'stampReferral'], 10, 2);
        add_filter('fluent_affiliate/affiliate_customers_query', [$this, 'filterLifetimeCustomers'], 10, 3);
        add_filter('fluent_affiliate/affiliate_customers_response', [$this, 'appendLifetimeExpiry'], 10, 2);
    }

    public function appendLifetimeExpiry($response, $affiliate)
    {
        $response['lifetime_expiry_days'] = $affiliate ? $this->getLifetimeExpiryDays($affiliate) : 0;
        return $response;
    }

    public function addDefaultLifetimeSettings($settings)
    {
        $settings['enable_lifetime_commission'] = 'no';
        $settings['lifetime_rate_type']         = 'percentage';
        $settings['lifetime_rate']              = 10;
        $settings['lifetime_expiry_days']       = ''; // empty/0 = no expiration

        return $settings;
    }

    public function addLifetimeFieldTypes($fieldTypes)
    {
        $fieldTypes['enable_lifetime_commission'] = ['yes', 'no'];
        $fieldTypes['lifetime_rate_type']         = ['percentage', 'fixed'];
        $fieldTypes['lifetime_rate']              = 'float';
        $fieldTypes['lifetime_expiry_days']       = 'number';

        return $fieldTypes;
    }

    public function addLifetimeSettingsToGroup($value, $data)
    {
        $value['enable_lifetime_commission'] = Arr::get($data, 'enable_lifetime_commission') === 'yes' ? 'yes' : 'no';
        $value['lifetime_rate_type']         = Arr::get($data, 'lifetime_rate_type') === 'fixed' ? 'fixed' : 'percentage';
        $value['lifetime_rate']              = (float) Arr::get($data, 'lifetime_rate');
        $value['lifetime_expiry_days']       = (int) Arr::get($data, 'lifetime_expiry_days');

        return $value;
    }

    public function resolveAffiliate($affiliate, $customerData, $provider)
    {
        // Cookie affiliate always wins.
        if ($affiliate) {
            return $affiliate;
        }

        $customer = $this->findBoundCustomer($customerData);
        if (!$customer || !$customer->by_affiliate_id) {
            return $affiliate;
        }

        $boundAffiliate = Affiliate::find($customer->by_affiliate_id);
        if (!$boundAffiliate || $boundAffiliate->status !== 'active') {
            return $affiliate;
        }

        if ($this->isLifetimeExpired($customer, $boundAffiliate)) {
            return $affiliate;
        }

        if ($this->isSelfReferred($boundAffiliate, $customer)) {
            return $affiliate;
        }

        return $boundAffiliate;
    }

    public function stampReferral($data, $provider)
    {
        // Only convert first-purchase types; leave recurring_sale and others intact.
        if (!in_array(Arr::get($data, 'type'), ['sale', 'payment'], true)) {
            return $data;
        }

        // Only act when there is no referral cookie (true lifetime fallback).
        if (Utility::getCurrentCookieAffiliate()) {
            return $data;
        }

        $customerId  = Arr::get($data, 'customer_id');
        $affiliateId = Arr::get($data, 'affiliate_id');
        if (!$customerId || !$affiliateId) {
            return $data;
        }

        $customer = Customer::find($customerId);
        if (!$customer || (int) $customer->by_affiliate_id !== (int) $affiliateId) {
            return $data;
        }

        $affiliate = Affiliate::find($affiliateId);
        if (!$affiliate || $affiliate->status !== 'active') {
            return $data;
        }

        if ($this->isLifetimeExpired($customer, $affiliate)) {
            return $data;
        }

        if ($this->isSelfReferred($affiliate, $customer)) {
            return $data;
        }

        $data['type']   = 'lifetime_sale';
        $data['amount'] = $this->getBaseLifetimeCommission($affiliate, (float) Arr::get($data, 'order_total', 0));

        return $data;
    }

    public function filterLifetimeCustomers($query, $request, $affiliateId)
    {
        $filter = $request->getSafe('filter', 'sanitize_text_field');
        if (!in_array($filter, ['active', 'expired'], true)) {
            return $query;
        }

        $affiliate  = Affiliate::find($affiliateId);
        $expiryDays = $affiliate ? $this->getLifetimeExpiryDays($affiliate) : (int) Utility::getReferralSetting('lifetime_expiry_days', 0);

        // No expiration configured: everyone is active, nobody is expired.
        if ($expiryDays <= 0) {
            if ($filter === 'expired') {
                $query->where('id', 0);
            }
            return $query;
        }

        $threshold = gmdate('Y-m-d H:i:s', time() - ($expiryDays * DAY_IN_SECONDS));
        $query->where('created_at', $filter === 'active' ? '>=' : '<', $threshold);

        return $query;
    }

    protected function isSelfReferred($affiliate, $customer)
    {
        if (Utility::getReferralSetting('self_referral_disabled') !== 'no') {
            return false;
        }

        $email = $customer->email;
        $affiliateEmail = $affiliate->user ? $affiliate->user->user_email : '';

        if ($email && ($email === $affiliate->payment_email || $email === $affiliateEmail)) {
            return true;
        }

        return !empty($customer->user_id) && (int) $customer->user_id === (int) $affiliate->user_id;
    }

    protected function findBoundCustomer($customerData)
    {
        $userId = Arr::get($customerData, 'user_id');
        $email  = Arr::get($customerData, 'email');

        // Deterministic match: prefer the logged-in user, then fall back to email.
        // Avoid a mixed `email = X OR user_id = Y` which could match two different
        // people and credit the wrong affiliate.
        if ($userId) {
            $customer = Customer::query()->where('user_id', $userId)->first();
            if ($customer) {
                return $customer;
            }
        }

        if ($email) {
            return Customer::query()->where('email', $email)->first();
        }

        return null;
    }

    protected function isLifetimeExpired($customer, $affiliate)
    {
        $expiryDays = $this->getLifetimeExpiryDays($affiliate);
        if ($expiryDays <= 0) {
            return false; // no expiration configured
        }

        $createdAt = $customer->created_at;
        if (!$createdAt) {
            return false;
        }

        return time() > (strtotime($createdAt) + ($expiryDays * DAY_IN_SECONDS));
    }
}
