<?php

namespace FluentAffiliatePro\App\Hooks\Handlers;

use FluentAffiliate\App\Helper\Utility;
use FluentAffiliate\Framework\Support\Arr;

class RecurringReferralHandler
{
    public function register()
    {
        add_filter('fluent_affiliate/default_referral_settings', [$this, 'addDefaultRecurringSettings']);
        add_filter('fluent_affiliate/referral_config_field_types', [$this, 'addRecurringFieldTypes']);

        if (Utility::getReferralSetting('enable_subscription_renewal', 'no') !== 'yes') {
            return;
        }

        add_filter('fluent_affiliate/create_affiliate_group_data_value', [$this, 'addRecurringSettingsToGroup'], 10, 2);
        add_filter('fluent_affiliate/update_affiliate_group_data_value', [$this, 'addRecurringSettingsToGroup'], 10, 2);
    }

    public function addDefaultRecurringSettings($settings)
    {
        $settings['enable_subscription_renewal'] = 'no';
        $settings['renewal_rate_type'] = 'percentage';
        $settings['renewal_rate'] = 10;
        $settings['max_renewal_count'] = 0;

        return $settings;
    }

    public function addRecurringFieldTypes($fieldTypes)
    {
        $fieldTypes['enable_subscription_renewal'] = ['yes', 'no'];
        $fieldTypes['renewal_rate_type'] = ['percentage', 'fixed'];
        $fieldTypes['renewal_rate'] = 'float';
        $fieldTypes['max_renewal_count'] = 'number';

        return $fieldTypes;
    }

    public function addRecurringSettingsToGroup($value, $data)
    {
        $value['enable_subscription_renewal'] = Arr::get($data, 'enable_subscription_renewal') === 'yes' ? 'yes' : 'no';
        $value['renewal_rate_type'] = Arr::get($data, 'renewal_rate_type') === 'percentage' ? 'percentage' : 'fixed';
        $value['renewal_rate'] = (float) Arr::get($data, 'renewal_rate');
        $value['max_renewal_count'] = (int) Arr::get($data, 'max_renewal_count');

        return $value;
    }
}